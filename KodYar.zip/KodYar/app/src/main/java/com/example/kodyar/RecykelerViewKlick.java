package com.example.kodyar;

public interface RecykelerViewKlick {
    public void onClick(int position);
    public void onLongClick(int position);
}
